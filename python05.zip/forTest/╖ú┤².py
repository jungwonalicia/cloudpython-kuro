import random
print(random.randint(1, 3))

print("--------------------")

choice = ["가위", "바위", "보"]  
print(random.choice(choice))




