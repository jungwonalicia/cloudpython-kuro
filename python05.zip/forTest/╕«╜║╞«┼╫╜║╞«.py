# ★★★★★★★★★★
for y in range(0, 3, 1):
    for x in range(0, 10, 1):
        print("★", end="")
    print()
print("----------")

# 
# ★
# ★★
# ★★★
# ★★★★
# ★★★★★
# ★★★★★★
# ★★★★★★★
# ★★★★★★★★
# ★★★★★★★★★
for y in range(0, 3, 1):
    for x in range(0, 10, 1):
        print("★" * x)
    print()
print("----------")















