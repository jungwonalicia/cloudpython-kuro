sum = 0 
for x in range(1, 11):
    sum = sum + x
print(sum)

# number = [1, 2, 3, 4, 5]
# 
# for x in range(0, 5, 1):
#     print(number[x])

# print(number[0])
# print(number[1])
# print(number[2])
# print(number[3])
# print(number[4])




