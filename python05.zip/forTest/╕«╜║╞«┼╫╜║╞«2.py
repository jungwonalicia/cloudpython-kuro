# for x in range(0, 10, 1):
#         print("★" * x) #x= 0, ...., 9

x = 0
while x < 10:
    print("★" * x)
    x = x + 1