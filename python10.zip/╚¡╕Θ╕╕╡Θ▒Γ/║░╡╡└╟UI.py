from tkinter import *

def img_change2():
    img()

def img():
    pass