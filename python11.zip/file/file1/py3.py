fileOutput = open("data6.txt", "w")
fileOutput.write("나는 새로운 내용이예요.\n")
fileOutput.write("나도 새로운 내용이예요.\n")


fileOutput.close()