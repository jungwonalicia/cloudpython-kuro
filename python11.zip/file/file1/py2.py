fileOutput = open("data6.txt", "a")
fileOutput.write("나는 추가된 내용이예요.\n")


fileOutput.close()