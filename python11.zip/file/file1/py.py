fileInput = open("data1.txt", "r")
line = fileInput.readline()
print(line)
line = fileInput.readline()
print(line)
line = fileInput.readline()
print(line)

fileInput.close()