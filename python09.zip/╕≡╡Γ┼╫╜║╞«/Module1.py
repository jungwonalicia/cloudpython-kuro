def func1():
    print("Module1의   func1()함수 호출됨...")

def func2():
    print("Module1의   func2()함수 호출됨...")

def func3():
    print("Module1의   func3()함수 호출됨...")

if __name__ == '__main__':
    func1()