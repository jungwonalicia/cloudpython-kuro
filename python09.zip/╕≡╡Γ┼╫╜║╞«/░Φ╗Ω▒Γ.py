'''
두 수를 입력받아 각각 처리해서 리턴!!
add, minus, mul, div
'''
