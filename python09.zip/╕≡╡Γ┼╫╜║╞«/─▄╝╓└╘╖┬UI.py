import 게시판db처리
if __name__ == '__main__':
    print("--------- 게시판  검색 처리 ----------")
    id = input("검색할 ID입력>>> ")
    result = 게시판db처리.read(id)
    print(result)
#     print(게시판db처리.read(id))
     
#     print()
#     a, b, c, d = 게시판db처리.read(id)
#     print(a, " ", b, " ", c, " ", d)
    
    print("--------- 게시판 등록 처리 ----------")
#     id = input("게시판 ID입력: ")
#     title = input("게시판 제목입력: ")
#     content = input("게시판 내용입력: ")
#     writer = input("게시판  작성자입력: ")
#     
#     게시판db처리.create(id, title, content, writer)

    print("--------- 게시판  삭제 처리 ----------")
#     delete문 처리: 
#         delete from bbs where id = ~~~~

    print("--------- 게시판  수정 처리 ----------")
#     update문 처리:
#         update bbs set content = ~~~ where id = ~~~
    
        
        
        
        
        
    
    
    
    
    
    
