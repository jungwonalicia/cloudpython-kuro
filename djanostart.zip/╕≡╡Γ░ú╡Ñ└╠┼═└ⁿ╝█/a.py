result = 0

def a1():
    global result
    result = 1

def a2():
    a1()
