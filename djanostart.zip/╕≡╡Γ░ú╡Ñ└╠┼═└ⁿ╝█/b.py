from 모듈간데이터전송 import a

a.a2()
print(a.result)

