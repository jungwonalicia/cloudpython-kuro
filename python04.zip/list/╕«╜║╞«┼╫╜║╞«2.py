name = ["김아무개", "박아무개"]

'''조원 전체 인원수 출력'''
print(len(name))

for i in range(0, len(name)):
    print("인덱스", i, ": ", name[i])