num = [10, 33, 55, 22, 99, 45]

print(num[0])
print(num[1])
print(len(num), "개")
num[2] = 66
print(num[2])

for i in range(0, len(num)):
    print(i , ": ", num[i])













