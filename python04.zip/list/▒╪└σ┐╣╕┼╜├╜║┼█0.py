seat = [[1, 2, 3],[4, 5, 6]]
for x in range(0, 2):
    for y in range(0, 3):
        print(seat[x][y], end=" ")
    print()