list = [0] * 10
print(list)

list[0] = 1
print(list)



