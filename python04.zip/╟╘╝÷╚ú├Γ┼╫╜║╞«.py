from color import colorTest

colorTest.call("색깔창 열리게 하기..")