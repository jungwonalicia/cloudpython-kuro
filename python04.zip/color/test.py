#range(0,2) => 0,1

seat = [[0, 0, 0]] * 3
print(seat)
