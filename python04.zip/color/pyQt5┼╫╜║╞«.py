import sys

from PyQt5.QtWidgets import *

app = QApplication(sys.argv)
s = QWidget()

s.show()


app.exec()