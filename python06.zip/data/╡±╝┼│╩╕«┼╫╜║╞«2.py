test = dict()
print(test.items())

print()
test['apple'] = "사과"
test['banana'] = "바나나"
test['sky'] = "하늘"

print(test.items())
