data = [(1, 100), (2, 200)]

for x in range(0, len(data)):
    print(data[x])
    print(data[x])
    