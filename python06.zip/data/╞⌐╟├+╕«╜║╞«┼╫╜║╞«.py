data1 = (1, 2, 3)

print(data1)
print(data1[0])
print(data1[0:2])
print(data1[1:])
print(data1[:2])

print()
data2 = "나는 파이썬 프로그래머입니다."
print(data2[0])
print(data2[0:3])

print()
print(len(data2))











