test = list()

test.append("aaa")
test.append("bbb")
test.append("ccc")

print(test)
print(test[0])
print(test[1])
print(test[0:2])
print(test[:2])
print(test[0:])
print(test[1:])

print()





