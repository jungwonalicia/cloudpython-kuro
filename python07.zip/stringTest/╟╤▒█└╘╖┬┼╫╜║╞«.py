data = input("한글입력: ")
data2 = input("한글입력: ")
data3 = input("한글입력: ")

data4 = []
data4.append(data)
data4.append(data2)
data4.append(data3)

print(data4)