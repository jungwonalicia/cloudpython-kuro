'''
Created on 2019. 4. 1.

@author: user
'''


def test():
    print(a, "test함수 호출.")
    
if __name__ == '__main__':
    a = 100
    print(a , "내가 스타트")
    
    a= 200
    test()
    
    