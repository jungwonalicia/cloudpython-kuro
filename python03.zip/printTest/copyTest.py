a = 100

b = a

print(a)
print(b)

print()
a = b = 200 
print(a)

def sum(x, y):
    return x + y
    
a = sum(200, 100)

print("반환 받은 값>>", a)













