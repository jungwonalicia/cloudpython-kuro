while True:
    data = int(input("데이터 입력, 종료-1 "))
    if data == -1:
        print("프로그램 종료")
        break

print("당신의 입력값: " , data)