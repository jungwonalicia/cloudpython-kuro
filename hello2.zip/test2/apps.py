from django.apps import AppConfig


class Test2Config(AppConfig):
    name = 'test2'
