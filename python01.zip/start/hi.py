data1 = 100
print(type(data1))

data2 = 'my name is'
print(type(data2))