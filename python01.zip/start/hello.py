#basic output : monitor출력
print("hi.....");
print('안녕하세요.');

#basic input : keyboard
name = input("your name: ")
year = input("your birth year: ")

print("your input name is ", name)
print("your input year is ", year)

yearInt = int(year)

age = 2019 - yearInt + 1
print("your age is ", age)









