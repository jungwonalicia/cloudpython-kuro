a = "aaa" + "bbb"
# a = "aaa" * "bbb"
a = "aaa" * 3
a = [1, 2, 3] * 3
print(a)

