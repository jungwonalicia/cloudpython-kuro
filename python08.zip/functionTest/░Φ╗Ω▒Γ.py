'''
1. 더하기, 2. 빼기, 3. 곱하기, 4. 나누기
'''
# def addNum(x, y, default=0): #매개변수
def addNum(x, y): #매개변수
    z = x + y
    print("두 수의 합은 ", z)
     
def minusNum(x, y): #매개변수
    z = x - y
    print("두 수의 차는 ", z)
     
def multiNum(x, y): #매개변수
    z = x * y
    print("두 수의  곱은 ", z)
     
def divNum(x, y): #매개변수
    z = x / y
    print("두 수의 나눗셈은 ", z) 
    

if __name__ == '__main__':
    print("나의 계산기가 시작됩니다.")
    addNum(200, 100)
    minusNum(200, 100)
    multiNum(200, 100)
    divNum(200, 100)
    
    
    
    
    
    
    
    