name = 111

def call():
    global name
    name = 100
    print(name)
    
def call2():
    print(name)

if __name__ == '__main__':
    print(name)
    call()
    call2()
    