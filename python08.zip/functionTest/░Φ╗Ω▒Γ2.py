'''
1. 더하기, 2. 빼기, 3. 곱하기, 4. 나누기
'''
# def addNum(x, y, default=0): #매개변수
def addNum(x, y): #매개변수
    z = x + y
    print("두 수의 합은 ", z)
     
def minusNum(x, y): #매개변수
    z = x - y
    print("두 수의 차는 ", z)
     
def multiNum(x, y): #매개변수
    z = x * y
    print("두 수의  곱은 ", z)
     
def divNum(x, y): #매개변수
    z = x / y
    print("두 수의 나눗셈은 ", z) 
    

if __name__ == '__main__':
    print("나의 계산기가 시작됩니다.")
    x = int(input("숫자1>> "))
    y = int(input("숫자2>> "))
    
    addNum(x, y)
    minusNum(x, y)
    multiNum(x, y)
    divNum(x, y)
    
    
    
    
    
    
    
    
    