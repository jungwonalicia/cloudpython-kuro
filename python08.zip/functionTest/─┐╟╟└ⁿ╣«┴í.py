'''
1. 인원 총 커피값 계산, 인원당 * 커피값
2. 총 지불 금액, 인원당 * 커피값이 1500원 초과시, 할인 2000원.
'''
'''
from functionTest.계산기 import addNum
함수 호출시 패키지부터, 모듈명까지 안써줘도 됨.
addNum(100,200)
'''
'''
import functionTest.계산기
함수 호출시 패키지부터, 모듈명까지 꼭 다 써주어야 함.
functionTest.계산기.addNum(100,200)
'''
'''
import functionTest.계산기 as com
함수 호출시 패키지부터, 모듈명까지 com으로 대체함.
as.addNum(100, 200)
'''
import functionTest.계산기

def coffeeSum(person, price):
    sum = person * price
    return sum

def coffeeSale(sum):
    if sum >= 15000:
        print("당신이 지불한 커피 금액은 === ", sum - 2000, "원")
    else:
        print("당신이 지불한 커피 금액은 === ", sum, "원")
        
    
if __name__ == '__main__':
    person = int(input("인원 입력>> "))
    price = int(input("커피값 입력>> "))
    
    sum = coffeeSum(person, price)
    coffeeSale(sum)
    functionTest.계산기.addNum(300, 200)
    
    
    
    
    
    
    