import random

if __name__ == '__main__':
    name = ["감자", "고구마", "양파"]
    print(random.choice(name))
    
    index = random.randrange(3)
    print(name[index])
    