if __name__ == '__main__':
    a = 100
    b = 200
    
    c, d = 300, 400
    
#     e, f = input("숫자 입력>> ").split(",")
    e, f = input("숫자 입력>> ").split()
    print(e)
    print(f)
    
    