'''
from functionTest.계산기 import addNum
함수 호출시 패키지부터, 모듈명까지 안써줘도 됨.
addNum(100,200)
'''
'''
import functionTest.계산기
함수 호출시 패키지부터, 모듈명까지 꼭 다 써주어야 함.
functionTest.계산기.addNum(100,200)
'''
'''
import functionTest.계산기 as com
함수 호출시 패키지부터, 모듈명까지 com으로 대체함.
as.addNum(100, 200)
'''
import functionTest.계산기
import python08.functionTest.계산기2 as com2

if __name__ == '__main__':
    functionTest.계산기.addNum(300, 200)
    com2.addNum(300, 100)
    
    
    
    
    
    
    