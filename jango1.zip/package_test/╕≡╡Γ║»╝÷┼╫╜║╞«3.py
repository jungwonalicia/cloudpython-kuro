from package_test import 모듈변수테스트

print(모듈변수테스트.전역변수)