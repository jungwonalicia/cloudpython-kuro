class dataTransfer:
    id = None
    pw = None
    name = None
    tel = None